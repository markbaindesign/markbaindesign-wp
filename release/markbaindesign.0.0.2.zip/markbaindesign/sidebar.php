<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package _mbbasetheme
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>



		<?php endif; // end sidebar widget area ?>
	</div><!-- #secondary -->
